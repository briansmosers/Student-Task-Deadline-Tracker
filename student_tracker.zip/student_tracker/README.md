# Student Task & Deadline Tracker

## What was wrong (per your lecturer's feedback)

1. **No backend routes existed.** `login.py` only had a `/` route that rendered the landing page. The landing page links to `/login` and `/signup`, but those routes didn't exist in the Flask app — clicking them would 404.
2. **No actual login logic.** `session`, `redirect`, and `url_for` were imported but never used. There was no user database, no password checking, nothing that could authenticate anyone.
3. **Wrong folder structure.** Flask's `render_template()` looks for HTML files inside a `templates/` folder, and `url_for('static', ...)` looks for assets inside a `static/` folder. The files were sitting loose, so even the one existing route would have crashed with a `TemplateNotFound` error if you ran it.

## What's in this version

- `login.py` — Flask app with working `/`, `/signup`, `/login`, `/dashboard`, and `/logout` routes.
- `templates/landing.html` — your original landing page, unchanged, just moved into `templates/`.
- `templates/login.html`, `templates/signup.html` — new pages styled to match the landing page.
- `templates/dashboard.html` — a placeholder page shown after a successful login. This is where the actual task-tracker UI (your friend's part, or whoever owns that feature) should go.
- `static/study_room.jpg` — your background image, moved into `static/`.
- `tracker.db` — a SQLite database, created automatically the first time you run the app. Stores `id`, `name`, `email`, `password_hash` for each user. Passwords are hashed with `werkzeug.security` (Flask's built-in tool) — never stored as plain text.

## How to run it

```bash
pip install -r requirements.txt
python login.py
```

Then open `http://127.0.0.1:5000/` in your browser. Sign up for an account, then sign in with it — you should land on the dashboard page.

## Merging in your friend's code

Whatever your friend built (task creation, the calendar, priority sorting, focus sessions) should plug into `login.py` as additional routes, ideally guarded the same way `/dashboard` is:

```python
@app.route('/tasks')
def tasks():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    # your friend's task logic here
```

`session['user_id']` is available in any route after login, so their task data can be tied to the logged-in user (e.g. a `tasks` table with a `user_id` foreign key referencing `users.id`).

If they used a different storage approach for tasks (their own database, JSON file, etc.), the cleanest path is usually to bring their table/model creation into `init_db()` here, alongside the existing `users` table, so everything lives in one `tracker.db`.

## One thing to fix before submitting

`app.secret_key = 'your_secret_key'` is a placeholder. Anyone who reads your code could forge session cookies with it. Swap it for something random, e.g.:

```python
import secrets
app.secret_key = secrets.token_hex(16)
```

(Just know this will log everyone out each time the server restarts, since regenerating the key invalidates existing sessions — fine for coursework, not for production.)
